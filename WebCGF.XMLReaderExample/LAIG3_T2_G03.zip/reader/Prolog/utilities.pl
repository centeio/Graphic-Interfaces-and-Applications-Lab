type(hh).
type(cc).
type(hc).

emptyList([]).